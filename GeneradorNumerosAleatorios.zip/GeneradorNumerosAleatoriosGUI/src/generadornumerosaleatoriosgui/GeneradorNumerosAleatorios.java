package generadornumerosaleatoriosgui;
import java.util.Random;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class GeneradorNumerosAleatorios extends javax.swing.JFrame {

    public GeneradorNumerosAleatorios() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Generar Numeros Aleatorios");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Ordenar los numeros");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jButton2)))
                .addContainerGap(110, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addComponent(jButton1)
                .addGap(43, 43, 43)
                .addComponent(jButton2)
                .addContainerGap(112, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    Random rand = new Random();
    
    try {
        File archivo = new File("numeros aleatorios.txt"); //para crear el archivo en el cual se guardaran los numeros
        PrintWriter escritor = new PrintWriter(archivo); //para escribir los numeros en el archivo creado anteriormente
        
        for (int i = 0; i < 1000000; i++) { //ciclo for con una variable i que ira incrementando en 1 hasta llegar al limite deseado
            int numero = rand.nextInt(20000001) - 10000000; // aqui es donde se le asigna el rango en el cual los numeros deben ser creados aleatoriamente
            escritor.println(numero);
        }
        
        escritor.close();//para cerrar los datos escritos en el archivo 
        JOptionPane.showMessageDialog(null, "Los numeros se han guardado en el archivo numeros aleatorios.txt");//para mostrar un dialogo en pantalla 
        
    } catch (FileNotFoundException e) {
    }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
                                                 
    try {
        // Leer los números desde el archivo original
        ArrayList<Integer> numeros = new ArrayList<>();//para crear un array en el que se ordenaran los numeros
        Scanner lector = new Scanner(new File("numeros aleatorios.txt"));//para leer los datos que se encuentran en el archivo de texto
        while (lector.hasNextInt()) {//ciclo while para leer cada uno de los numeros en el archivo
            numeros.add(lector.nextInt());
        }
        lector.close();
        
        // Ordenar los números
        Collections.sort(numeros);
        
        // Escribir los números ordenados en un nuevo archivo
        File archivoOrdenado = new File("numeros ordenados.txt");// para crear un nuevo archivo de texto en donde se almacenan los valores ordenados
        PrintWriter escritor = new PrintWriter(archivoOrdenado);// para escribir los nuevos en el nuevo orden
        numeros.forEach((numero) -> {//para escribir los numeros del array al nuevo archivo de texto
            escritor.println(numero);
        });
        escritor.close();//cerrar el escritor
        
        JOptionPane.showMessageDialog(null, "Los numeros se han ordenado y guardado en el archivo numeros ordenados.txt");
        
    } catch (FileNotFoundException e) {
    }

    }//GEN-LAST:event_jButton2ActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GeneradorNumerosAleatorios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GeneradorNumerosAleatorios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GeneradorNumerosAleatorios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GeneradorNumerosAleatorios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GeneradorNumerosAleatorios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    // End of variables declaration//GEN-END:variables
}
